# CLAUDE.md

@AGENTS.md
@TODO.md

## Claude Code specifics

- **Progressive context loading.** Grep/Glob first, open only the files the task needs. Never read
  `src/components/ui/**`, `db/bootstrap.sql`, `grok-ref/**`, `abe-dashboard/**` unless the task names them.
- **Task isolation.** Fix only the assigned `TODO.md` item. Note unrelated problems under
  `TODO.md → Discovered` instead of fixing them.
- **Pick work** from `TODO.md` top-down: lowest phase first, `P0` before `P1`. Respect `blocked-by`.
- **Plan mode** for any item tagged `[L]` or touching >5 files: output the MAP (files, tables, procedures,
  invariants from AGENTS.md §5) before editing.
- **Subagents** (`.claude/agents/`): `security-reviewer` after every change under `api/` or `db/`;
  `migration-author` for any `db/schema.ts` change; `ui-builder` for `src/` screens. Run independent lanes in parallel.
- **Output style.** Terse. Diagnostic logs and diffs, no preamble. Report: item ID, files changed, verify result,
  follow-ups.
- **Commits.** One `TODO.md` item per commit: `<ID>: <imperative summary>`. Never commit with a red security gate.
- **Compact** context when an item is done or you switch lanes.
