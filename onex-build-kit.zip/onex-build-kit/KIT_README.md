# ONE-X build kit — install

Drop these into the root of `app/` (the Vite + Hono + tRPC codebase from the spec archive):

| File | Action |
|---|---|
| `AGENTS.md`, `CLAUDE.md`, `TODO.md` | add |
| `docs/*` | add |
| `.claude/agents/*` | add (Claude Code subagents) |
| `scripts/security-gate.mjs` | add |
| `vercel.json`, `.env.example` | **replace** |
| `.github/workflows/ci.yml` | add |

Add to `package.json` → `scripts`:

```json
"test:security": "node scripts/security-gate.mjs",
"test:int": "vitest run --config vitest.int.config.ts",
"test:e2e": "playwright test",
"verify": "npm run lint && npm run check && npm test && npm run test:security && npm run build"
```

Remove from `.gitignore`: `package-lock.json`, `db/migrations/*.sql`.

Baseline: `npm run test:security` on the spec code = **FAIL (84)**. Phase 0–1 of `TODO.md` takes it to PASS.
Start a Claude Code session with prompt §0 in `docs/PROMPTS.md`.
