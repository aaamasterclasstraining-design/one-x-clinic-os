# ARCHITECTURE.md — ONE-X Clinic OS

## 1. Runtime topology

```
Browser (React SPA, Vercel CDN)
   │  HTTPS, cookie __Host-onex_sid
   ▼
Vercel Function  api/[...slug].ts  (Node 22, sin1, 30 s)
   └─ Hono  ── /api/trpc/*        → tRPC router (authedProcedure + can())
            ── /api/cron/*        → scheduled jobs (CRON_SECRET)
            ── /api/webhooks/*    → payment gateway (signature-verified)
            ── /api/health        → DB ping + migration version
   │  mysql2 pool (≤5, TLS)
   ▼
MySQL-compatible serverless DB (TiDB Cloud / PlanetScale, ap-southeast-1)
Vercel Blob (private)  — signatures, attachments, logos
Resend / SMS provider  — outbound comms
```

One function keeps cold starts shared and fits every Vercel plan. Split only if a route needs a different
runtime/duration (ADR required).

## 2. Request pipeline

`Hono` → body limit 1 MB → origin check (mutations) → request id → tRPC `createContext`
(session lookup, tenant, branches, capabilities) → `authedProcedure` → `can(cap)` → zod `.strict()` input →
router (thin) → domain service in `queries/*` (transaction + audit) → projection → superjson response.

## 3. Bounded contexts

| Context | Router | Service | Tables |
|---|---|---|---|
| Identity | `auth`, `profile` | `queries/auth.ts` | users, sessions, user_branches, rate_limits |
| Setup | `setup` | `queries/setup.ts` | tenants, settings, branches, rooms, providers, services, professional_fee_rules |
| Patients | `onex.patients` | `queries/patients.ts` | patients, patient_consents, phi_access_log |
| Care | `care` | `queries/care.ts` | appointments, visits, soap_notes, clinical_documents |
| Surgery | `onex.surgery` | `queries/surgery.ts` | surgical_cases, surgical_calendar_blocks, case_checklist_items, case_team_members, case_supply_usage |
| PF | `onex.pf` | `queries/pf.ts` | surgical_professional_fees, pf_revisions |
| Billing/POS | `pos`, `onex.billing` | `queries/billing.ts` (**only** writer) | orders, order_items, payments, refunds, cashier_shifts |
| Inventory | `inventory` | `queries/inventory.ts` | inventory_items, inventory_stock, inventory_ledger, purchase_orders, transfers |
| Documents | `docs` | `queries/docs.ts` | documents, doc_counters |
| Audit | `onex.audit` | `queries/audit.ts` | audit_events, audit_chain_head |
| Insights | `onex.insights` | `queries/insights.ts` | read-only views |

## 4. Core state machines

**Surgical case** (`CASE_TRANSITIONS`, `queries/domain.ts`)

```
PLANNING → TENTATIVE → SCHEDULED → PRE_OP → READY → IN_PROCEDURE → RECOVERY → COMPLETED → DISCHARGED → FOLLOW_UP → CLOSED
   └─ (PLANNING..READY) → POSTPONED → TENTATIVE | CANCELLED
   └─ (PLANNING..READY) → CANCELLED
```
Guard: `READY → IN_PROCEDURE` requires `readinessStatus = READY` or an audited override.

**PF**: `DRAFT → COMPUTED → REVIEWED → APPROVED → BILLABLE → PAID` (approver ≠ computer/adjuster).

**Order**: `DRAFT → SUBMITTED → PARTIALLY_PAID → PAID`; `* → VOID` (unpaid only); refunds are separate rows.

**Document**: `DRAFT → FINAL` (immutable) `→ VOID` (reason).

## 5. Money path

```
posCheckout(lines, patientId, method, idemKey)
  tx: lock-free re-price from catalog → insert order + items
      → per product: UPDATE stock … WHERE qty ≥ n (fail → rollback) → ledger row
      → insert payment (UNIQUE idem key; dup → return original)
      → audit(tx, 'order', id, 'POS_SALE')
assembleCaseBill(caseId) → procedure + PF(BILLABLE) + supplies − discounts → order SUBMITTED
pay(orderId, amount, method, idemKey) → tx: SELECT order FOR UPDATE → bounds → payment → status → audit
```

## 6. Audit chain

```
audit(tx, entity, entityId, action, detail):
  head = SELECT last_hash FROM audit_chain_head WHERE tenant_id=? FOR UPDATE
  created_at = now(ms)
  hash = sha256(canonicalJSON{tenant_id, entity, entity_id, action, detail, actor_id, prev_hash, created_at})
  INSERT audit_events(...) ; UPDATE audit_chain_head SET last_hash=hash
verifyAuditChain(tenant): recompute sequentially; report first broken id.
```
Lock contention is per tenant and short; acceptable at clinic scale. Daily cron verifies.

## 7. Frontend

React Router 7 routes (lazy per page) → shell (`Layout`) → pages. Data via `@trpc/react-query`.
Session from `auth.me`; `localStorage` holds only theme + last profile tile. Design tokens in `src/index.css`
(light/dark). Print routes `/print/*` render outside the shell.

Target routes: `/` dashboard · `/patients` · `/patients/:id` · `/appointments` · `/visits` · `/visits/:id` ·
`/surgery` · `/surgery/cases/:id` · `/sell` · `/billing` · `/inventory` · `/insights` · `/audit` · `/admin/*` ·
`/print/doc/:id` · `/print/receipt/:id`.

## 8. References in the spec archive

- `app/` — the codebase to evolve (this architecture).
- `grok-ref/` — TanStack Start prototype: **visual** reference for shell, dashboard cards, module list.
- `abe-dashboard/` — Next.js config stub; Apple Business Essentials visual language reference (`plan.md`).
Neither reference is merged as code.
