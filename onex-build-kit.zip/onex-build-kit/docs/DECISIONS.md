# DECISIONS.md — Architecture Decision Records

Format: `ADR-NNN — Title` · Status · Context · Decision · Consequences. Append only.

## ADR-001 — Keep Vite SPA + Hono/tRPC on a single Vercel function
**Accepted.** Spec ships React 19/Vite 7 + tRPC 11/Hono with one catch-all function. Migrating to Next.js
(abe-dashboard) or TanStack Start (grok-ref) buys SSR the app doesn't need (authenticated back-office tool).
Keep the stack; references are visual only. Revisit only if a public patient portal needs SSR/SEO.

## ADR-002 — MySQL-compatible serverless DB (TiDB Cloud first)
**Accepted.** Schema, Drizzle dialect and bootstrap SQL are MySQL/TiDB. Switching to Postgres costs a full
schema port with no product gain. TiDB Serverless: free tier, `ap-southeast-1`, branching.

## ADR-003 — Server sessions + PIN quick-switch (replaces PIN-only localStorage profiles)
**Accepted.** Clinic front desks share devices; staff need fast switching. PIN alone (4–6 digits) is not a
credential. Decision: tenant users authenticate with password (+TOTP for admins) creating a device session;
PIN switches the active user on that device, rate-limited and locked out. Identity lives in DB sessions.

## ADR-004 — Shared-schema multi-tenancy with `tenant_id`
**Accepted.** White-label SaaS for many clinics. Shared schema + `tenant_id` + enforced repository filter +
cross-tenant integration tests. DB-per-tenant deferred until a tenant contract requires it.

## ADR-005 — Single money path in `queries/billing.ts`
**Accepted.** All order/payment/refund writes in one service with transactions, idempotency and audit.
Enforced by the security gate.

## ADR-006 — Audit chain per tenant with locked head row
**Accepted.** Tamper evidence requires a verifiable, linear chain. Serialize per tenant via
`audit_chain_head FOR UPDATE`; hash persisted fields only; write in the business transaction.

## ADR-007 — Money as integer centavos in TypeScript
**Accepted.** `DECIMAL(12,2)` in DB; convert at the boundary; no float arithmetic.
