# DEPLOY_VERCEL.md — production runbook

## 1. Plan

- **Vercel Pro** for production (Hobby is limited to non-commercial use per Vercel's terms — confirm on
  vercel.com/pricing). Pro also unlocks sub-daily crons and higher function limits.
- Region: **`sin1`** (Singapore) — lowest latency to Manila. DB must be in the same region
  (AWS `ap-southeast-1`).

## 2. Database

The existing `db/bootstrap.sql` carries TiDB syntax (`/*T![clustered_index] CLUSTERED */`), so the spec was
generated against TiDB. Options (all MySQL-wire compatible, work with `drizzle-orm/mysql2`):

| Option | Notes |
|---|---|
| **TiDB Cloud Serverless** (recommended) | Free tier available, `ap-southeast-1`, branching for previews, TLS required. |
| PlanetScale | Paid plans only (free Hobby tier was discontinued); branching + deploy requests. |
| AWS RDS/Aurora MySQL | Needs RDS Proxy for serverless connection pooling. |

Setup:
1. Create cluster in `ap-southeast-1`. Create databases/branches: `onex_prod`, `onex_preview`.
2. Create **two users per env**: `onex_app` (DML only; no DDL; no UPDATE/DELETE on `audit_events` where
   supported) and `onex_migrator` (DDL). App runtime uses `onex_app`.
3. Run migrations from CI or locally with the migrator URL: `DATABASE_URL=$MIGRATOR_URL npm run db:migrate`.
4. Enable PITR / automated backups.

Connection string: `mysql://onex_app:<pw>@<host>:4000/onex_prod?ssl={"rejectUnauthorized":true}`

## 3. Environment variables

| Name | Prod | Preview | Dev | Notes |
|---|---|---|---|---|
| `DATABASE_URL` | ✓ | ✓ (preview DB) | local | app user |
| `MIGRATOR_DATABASE_URL` | CI only | CI only | local | never in runtime env |
| `SESSION_SECRET` | ✓ | ✓ (different) | ✓ | ≥32 random bytes, `openssl rand -base64 48` |
| `CRON_SECRET` | ✓ | ✓ | – | Vercel sends as `Authorization: Bearer` |
| `APP_URL` | ✓ | – (use `VERCEL_URL`) | `http://localhost:3000` | origin check |
| `BLOB_READ_WRITE_TOKEN` | ✓ | ✓ | opt | auto-added when Blob store linked |
| `RESEND_API_KEY`, `MAIL_FROM` | ✓ | opt | – | COM-01 |
| `HITPAY_API_KEY`, `HITPAY_SALT` | ✓ | sandbox | – | BIL-06 |
| `SENTRY_DSN` | ✓ | ✓ | – | server; `VITE_SENTRY_DSN` for client (DSN is not secret) |

Never prefix secrets with `VITE_`.

## 4. Project settings

- Framework preset: Vite. Build: `npm run build`. Output: `dist/public`. Install: `npm ci`. Node 22.x.
- `vercel.json` (kit version) sets region, function limits, headers, crons, SPA rewrite.
- Git: `main` → Production; every PR → Preview (preview DB). Enable "Deployment Protection" (Vercel
  Authentication) on previews — they contain a working app.

## 5. Migrations in the release flow

```
PR → CI (verify + test:int on ephemeral MySQL) → merge
   → CI job "migrate": MIGRATOR_DATABASE_URL (prod) npm run db:migrate
   → Vercel production deploy (git) 
```
Rules: migrations are additive/backward-compatible (expand → deploy → contract). Destructive steps ship in a
later release after code no longer reads the column.

## 6. Crons (`vercel.json`)

| Path | Schedule (UTC) | Purpose |
|---|---|---|
| `/api/cron/reminders` | `0 * * * *` | appointment reminders (Pro; on Hobby use daily) |
| `/api/cron/audit-verify` | `0 19 * * *` | 03:00 Manila — verify chain per tenant, alert on break |
| `/api/cron/reconcile` | `30 19 * * *` | 03:30 Manila — orders/payments/ledger/PF mismatches |

Handler guard: `if (c.req.header("authorization") !== \`Bearer ${env.CRON_SECRET}\`) return c.text("", 401)`.

## 7. Security headers

Set in `vercel.json` for all routes. CSP allows `self` plus Vercel Speed Insights endpoints; add Sentry ingest
host and remove `fonts.googleapis.com`/`fonts.gstatic.com` once fonts are self-hosted (OPS-13).

## 8. Rollback

- App: Vercel → Deployments → previous production → **Instant Rollback**.
- DB: migrations are forward-only; rollback = new corrective migration. For data loss use PITR to a new
  branch, verify, then cut over.

## 9. Go-live checklist

- [ ] Phases 0–2 of `TODO.md` complete; QA-01..QA-04 green.
- [ ] `npm run verify` green on the release commit; security gate green.
- [ ] Prod DB: app user least-privilege, PITR on, backup restore tested.
- [ ] Env vars set for Production only where required; previews use preview DB.
- [ ] Custom domain, HTTPS, headers verified (securityheaders.com grade A).
- [ ] First Owner created via CLI seed; default/demo profiles removed.
- [ ] Unauthenticated probe of `/api/trpc/onex.patients.list` returns 401.
- [ ] Audit verify cron ran successfully once.
- [ ] End-to-end sale + refund + surgical case completed on production with test patient, then voided.
- [ ] Privacy notice + DPO contact live; staff trained.
