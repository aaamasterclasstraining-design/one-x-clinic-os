# PROMPTS.md — copy-paste kickoff prompts

Use in Claude Code (or any agent) at repo root. Each prompt assumes `AGENTS.md`, `CLAUDE.md`, `TODO.md` exist.

---

## 0. Session bootstrap (paste first in any new session)

```
Read AGENTS.md and TODO.md. Do not read other files yet.
Report: next 3 unblocked TODO items (lowest phase, highest priority), their blocked-by status, and the
invariants (AGENTS.md §5) each touches. No edits.
```

## 1. Phase 0 — baseline

```
Execute TODO.md Phase 0 items OPS-01 through OPS-08 and OPS-10, OPS-11, one commit per item.
MAP first: list files per item. For OPS-04 generate the baseline migration from db/schema.ts, diff it
against db/bootstrap.sql, and list every difference before resolving. Do not touch routers or src/.
VERIFY: npm run check && npm run build. Report item → commit → result.
```

## 2. Phase 1 — auth + authorization (plan mode)

```
Plan mode. Items SEC-01, SEC-02, SEC-03, SEC-05, SEC-06 (ADR-003 in docs/DECISIONS.md).
MAP: every procedure in api/_server/routers/** with its current input actor fields and the capability it
will require (table: router.procedure | cap | removes actor field?). Show the schema for users/sessions and
the context/middleware signatures. Wait for approval before editing.
After approval: implement, then write QA-02 test that enumerates the router and asserts 401 for every
non-allowlisted procedure. VERIFY: npm run verify. Run security-reviewer subagent on the diff.
```

## 3. Phase 1 — money + audit hardening

```
Items SEC-07, SEC-08, SEC-09, SEC-10 and DAT-05. Characterization tests FIRST that fail on current code:
(1) 10 concurrent identical checkouts → exactly 1 order; (2) pay() with negative amount rejected;
(3) pay() beyond outstanding rejected; (4) concurrent audit() calls produce a single valid chain;
(5) tampering one audit row is detected by verifyAuditChain. Then fix. Money in centavos.
Audit writes move inside the caller's transaction. VERIFY: npm run verify && npm run test:int.
```

## 4. Phase 2 — tenancy

```
Plan mode. DAT-01, DAT-02, DAT-03. Use migration-author subagent for schema + migration (expand-only).
MAP every table → tenant-owned? branch-scoped? → index changes. Add tenantScope() helper and apply to every
query. Integration test: tenant A cannot read or mutate tenant B rows by id through any procedure.
```

## 5. Feature lane (template)

```
Implement TODO <ID>. Lane: <api|ui|data>. Stay inside the lane's files (AGENTS.md §10).
Procedure checklist: authedProcedure + can(<cap>) + .strict() bounded zod + tenant filter + tx + audit.
UI checklist: tokens only, loading/empty/error, 390×844, keyboard, labels.
VERIFY: npm run verify; screenshot desktop + mobile if UI. Tick TODO with commit hash.
```

## 6. Parallel build (lead agent)

```
Contract is frozen (schema, contracts/, middleware). Dispatch in parallel:
- api lane: CLN-01 procedures (appointments)
- ui lane: CLN-01 screens against the procedure signatures in contracts/
- qa lane: QA-05 e2e for booking → check-in
Each lane: own files only. When all return, integrate on one branch, run npm run verify, fix conflicts.
```

## 7. Pre-release review

```
Run security-reviewer on git diff main...HEAD. Then run docs/DEPLOY_VERCEL.md §9 checklist items that
are verifiable from the repo and report each as PASS/FAIL/NEEDS-HUMAN with evidence (command + output).
```
