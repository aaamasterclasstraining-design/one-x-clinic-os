# SECURITY.md — ONE-X Clinic OS

## 1. Threat model (summary)

| Asset | Threat | Primary control |
|---|---|---|
| Patient health info (PHI) | Unauthenticated / cross-tenant read, over-broad staff access | Sessions, tenant filter, COMMERCE/CLINICAL projection, PHI access log |
| Money (orders, payments, PF) | Forged payments, double charge, price tampering, silent edits | Single money path, server re-pricing, unique idempotency, tx + audit, SoD on PF |
| Inventory | Negative stock, untraceable adjustments | Conditional decrement, append-only ledger |
| Audit trail | Tampering, gaps, unverifiable chain | Locked chain head, hash over persisted fields, in-tx audit, no UPDATE/DELETE |
| Staff accounts | PIN brute force, privilege escalation | scrypt, rate limit, lockout, capability grant ≤ own |
| Availability | Oversized payloads, connection exhaustion | 1 MB body, pool limit 5, rate limits |

## 2. Findings from the spec audit (2026-09-25)

| ID | Sev | Finding | Location | Fix |
|---|---|---|---|---|
| F-01 | Critical | Every tRPC procedure is `publicQuery` — patients, clinical notes, payments, capability changes callable by anyone with the URL | `api/_server/middleware.ts`, all routers | SEC-01/02 |
| F-02 | Critical | Admin mutations (`setCapabilities`, `resetPin`, `setActive`, `setBrand`) have no auth — any caller can make themselves admin or reset any PIN | `routers/profile.ts:82-135` | SEC-06 |
| F-03 | Critical | Actor is client-supplied (`actor`, `createdBy`) — audit trail attributes actions to whatever name the caller sends | `care.ts`, `onex.ts`, `profile.ts`, `docs.ts` | SEC-03 |
| F-04 | High | Identity + capabilities trusted from `localStorage` | `src/lib/session.ts` | SEC-12 |
| F-05 | High | PIN hashed with single SHA-256 + static global salt; 4-digit PIN space brute-forceable offline in milliseconds and online with no rate limit | `profile.ts:9-10,37` | SEC-04, SEC-13 |
| F-06 | High | `billing.pay` accepts any amount (negative, zero, overpayment), on any order status, outside a transaction | `onex.ts:452` | SEC-09 |
| F-07 | High | `payments.idempotency_key` not unique — check-then-insert race allows double charge | `db/bootstrap.sql:194`, `care.ts` checkout | SEC-08 |
| F-08 | High | Audit hash includes `Date.now()` that is never stored → chain cannot be recomputed/verified; head read without lock → concurrent writes fork the chain; audit written outside the business tx → lost events on crash | `queries/domain.ts:10-12` | SEC-07 |
| F-09 | High | No tenant or branch isolation in any query | all routers | DAT-01/02 |
| F-10 | Medium | No PHI projection: POS catalog/search return full patient rows | `onex.ts:48,70`, `care.ts:114` | SEC-11 |
| F-11 | Medium | Body limit 50 MB (platform cap 4.5 MB) | `boot.ts:11` | OPS-06 |
| F-12 | Medium | Unbounded zod numbers/strings | all routers | SEC-10 |
| F-13 | Medium | Lockfile and migrations git-ignored → non-reproducible builds and schema | `.gitignore` | OPS-02/03 |
| F-14 | Low | `doc_counters` table exists only in `bootstrap.sql`, not `schema.ts` (drift) | `docs.ts:47` | OPS-04 |
| F-15 | Low | Doc number year from server UTC clock (wrong 00:00–08:00 Manila on Jan 1) | `docs.ts:45` | DAT-06 |
| F-16 | Low | No security headers (CSP, HSTS, frame-ancestors) | `vercel.json` | OPS-07 |

## 3. Controls (target state)

**Authentication.** Email + password (scrypt, N=2^15, r=8, p=1, 64 B key, 16 B salt) per user. Server
sessions in DB, opaque 32-byte id, cookie `__Host-onex_sid` (HttpOnly, Secure, SameSite=Lax). Rotate id on
sign-in and privilege change. PIN quick-switch only on a device session; lockout after 5 failures / 15 min.
TOTP for Owner/Admin.

**Authorization.** `authedProcedure` + `can(cap)`. Capability catalog in `contracts/capabilities.ts`.
Grant rule: a user may only grant capabilities they hold; `users.manage` required; last Owner cannot be demoted.

**Tenancy.** `tenant_id` on every tenant-owned row; repository helpers inject the filter; integration test
enumerates routers and asserts cross-tenant access fails.

**PHI.** Projection scopes; `phi_access_log` for clinical reads; no PHI in logs/Sentry (`beforeSend` scrubs
bodies/query strings); attachments in private Blob with ≤5 min signed URLs; exports capability-gated + audited.

**Transport & browser.** HTTPS only, HSTS, CSP (`default-src 'self'`), `frame-ancestors 'none'`,
`Referrer-Policy: strict-origin-when-cross-origin`, `Permissions-Policy` (camera only if photo capture enabled).
Origin check on mutations.

**Secrets.** Vercel env vars per environment (Production / Preview / Development). Never `VITE_`-prefixed.
Rotate `SESSION_SECRET`, DB password, gateway keys on staff offboarding of anyone with access.

**Data at rest.** Provider-managed encryption (TiDB/PlanetScale default). Backups with PITR + encrypted
weekly export.

## 4. Data Privacy Act (RA 10173) checklist

Confirm specifics with the clinic's Data Protection Officer / counsel — items below are engineering hooks,
not legal advice.

- [ ] Privacy notice shown and consent recorded at patient registration (`patient_consents` with version).
- [ ] DPO name/contact configurable in settings and shown on notices.
- [ ] Purpose-limited access (projection scopes) and access logging.
- [ ] Data subject request workflow (access, correction, erasure where lawful) with audit.
- [ ] Retention schedule per record type; archival job; no silent deletes of medical records.
- [ ] Breach response runbook with notification timeline per current NPC circulars.
- [ ] Processor agreements with DB, hosting, email/SMS, payment providers.

## 5. Reporting

Security issues: report privately to the platform owner. Do not open public issues containing PHI or exploit
details.
