#!/usr/bin/env node
// ONE-X security gate — static tripwires for AGENTS.md §5/§8. Exit 1 on any violation.
// Usage: node scripts/security-gate.mjs [rootDir]
import { readFileSync, readdirSync, statSync } from "node:fs";
import { join, relative } from "node:path";

const ROOT = process.argv[2] ?? process.cwd();

// Procedures allowed to stay public: "<file-basename>:<procedureName>"
const PUBLIC_ALLOW = new Set([
  "router.ts:ping",
  "auth.ts:signIn",
  "auth.ts:signOut",
  "profile.ts:getBrand",
]);
const BILLING_SERVICE = "api/_server/queries/billing.ts";
const SURGERY_TRANSITION_FILES = new Set(["api/_server/queries/surgery.ts", "api/_server/queries/domain.ts"]);

function walk(dir, out = []) {
  let entries;
  try { entries = readdirSync(dir); } catch { return out; }
  for (const e of entries) {
    if (e === "node_modules" || e === "dist" || e.startsWith(".")) continue;
    const p = join(dir, e);
    const s = statSync(p);
    if (s.isDirectory()) walk(p, out);
    else if (/\.(ts|tsx|mjs|js)$/.test(e) && !/\.(test|spec)\.|__tests__/.test(p)) out.push(p);
  }
  return out;
}

const violations = [];
const flag = (file, line, rule, text) =>
  violations.push({ file: relative(ROOT, file), line, rule, text: text.trim().slice(0, 140) });

const apiFiles = walk(join(ROOT, "api"));
const srcFiles = walk(join(ROOT, "src")).filter((f) => !/[\\/]components[\\/]ui[\\/]/.test(f)); // shadcn primitives excluded

for (const file of apiFiles) {
  const rel = relative(ROOT, file).replaceAll("\\", "/");
  const base = rel.split("/").pop();
  const lines = readFileSync(file, "utf8").split("\n");
  lines.forEach((l, i) => {
    const n = i + 1;
    const pub = l.match(/^\s*([A-Za-z0-9_]+)\s*:\s*(publicQuery|publicProcedure)\b/);
    if (pub && !PUBLIC_ALLOW.has(`${base}:${pub[1]}`)) flag(file, n, "public-procedure", l);

    if (/\b(actor|createdBy|receivedBy|approvedBy)\s*:\s*z\./.test(l)) flag(file, n, "client-actor-input", l);

    if (/\.insert\(\s*(orders|payments|refunds)\s*\)/.test(l) && rel !== BILLING_SERVICE)
      flag(file, n, "money-path-bypass", l);

    if (/\.(update|delete)\(\s*auditEvents\s*\)/.test(l)) flag(file, n, "audit-mutation", l);

    if (/\.update\(\s*surgicalCases\s*\)\.set\(\{[^}]*\bstatus\s*:/.test(l) && !SURGERY_TRANSITION_FILES.has(rel))
      flag(file, n, "case-status-bypass", l);

    if (/\bconsole\.log\(/.test(l) && rel !== "api/_server/boot.ts") flag(file, n, "console-log-in-api", l);

    if (/createHash\(\s*["']sha256["']\s*\)/.test(l) && /pin|password|SALT/i.test(lines.slice(Math.max(0, i - 2), i + 3).join("\n")))
      flag(file, n, "weak-credential-hash", l);
  });
  const text = lines.join("\n");
  if (/bodyLimit\(\{\s*maxSize:\s*(\d+)\s*\*\s*1024\s*\*\s*1024/.test(text)) {
    const mb = Number(text.match(/bodyLimit\(\{\s*maxSize:\s*(\d+)/)[1]);
    if (mb > 4) flag(file, 0, "body-limit-exceeds-vercel", `bodyLimit ${mb} MB`);
  }
}

for (const file of srcFiles) {
  readFileSync(file, "utf8").split("\n").forEach((l, i) => {
    if (/dangerouslySetInnerHTML/.test(l)) flag(file, i + 1, "dangerous-html", l);
    if (/import\.meta\.env\.VITE_[A-Z_]*(SECRET|KEY|TOKEN|PASSWORD)/.test(l) && !/SENTRY_DSN/.test(l))
      flag(file, i + 1, "secret-in-vite-env", l);
  });
}

try {
  const env = readFileSync(join(ROOT, ".env.example"), "utf8");
  env.split("\n").forEach((l, i) => {
    if (/^VITE_[A-Z_]*(SECRET|KEY|TOKEN|PASSWORD)=/.test(l)) flag(join(ROOT, ".env.example"), i + 1, "secret-in-vite-env", l);
  });
} catch { /* optional */ }

if (!violations.length) {
  console.log("security-gate: PASS");
  process.exit(0);
}
const byRule = violations.reduce((m, v) => ((m[v.rule] = (m[v.rule] ?? 0) + 1), m), {});
console.log(`security-gate: FAIL (${violations.length})`);
console.log(Object.entries(byRule).map(([r, c]) => `  ${r}: ${c}`).join("\n"));
for (const v of violations) console.log(`${v.file}:${v.line}  [${v.rule}]  ${v.text}`);
process.exit(1);
